import React, { useState } from 'react';
import { X, Cloud, HardDrive, Check, AlertCircle, Info } from 'lucide-react';

interface FirebaseConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  isFirebaseActive: boolean;
  onToggleFirebase: (enabled: boolean) => void;
}

export const FirebaseConfigModal: React.FC<FirebaseConfigModalProps> = ({
  isOpen,
  onClose,
  isFirebaseActive,
  onToggleFirebase,
}) => {
  const [projectId, setProjectId] = useState('');
  const [apiKey, setApiKey] = useState('');

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (projectId.trim() && apiKey.trim()) {
      onToggleFirebase(true);
      alert('Đã lưu cấu hình Firebase! (Chế độ Cloud Sync bật).');
      onClose();
    } else {
      alert('Vui lòng nhập đầy đủ Project ID và API Key nếu muốn kết nối Firebase.');
    }
  };

  const handleUseLocal = () => {
    onToggleFirebase(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-200">
        <div className="bg-[#005BAB] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Cloud className="w-5 h-5" />
            <h2 className="text-lg font-bold">Cấu hình Đồng bộ Đám mây (Firebase)</h2>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3.5 text-xs text-blue-800 flex items-start space-x-2.5">
            <Info className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold mb-1">Chế độ hoạt động hiện tại:</p>
              <p>
                Ứng dụng mặc định sử dụng <strong>LocalStorage</strong> trên trình duyệt để lưu trữ toàn bộ văn bản và ghi chú công việc an toàn, chạy ngay lập tức mà không bắt buộc cấu hình.
              </p>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Firebase Project ID
              </label>
              <input
                type="text"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                placeholder="my-vnpt-task-project"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#005BAB]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase mb-1">
                Firebase API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#005BAB]"
              />
            </div>

            <div className="pt-3 flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={handleUseLocal}
                className="w-full py-2 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-xs flex items-center justify-center space-x-1 transition"
              >
                <HardDrive className="w-4 h-4 text-slate-500" />
                <span>Sử dụng LocalStorage</span>
              </button>
              <button
                type="submit"
                className="w-full py-2 px-4 bg-[#005BAB] hover:bg-[#004a8b] text-white font-semibold rounded-lg text-xs flex items-center justify-center space-x-1 transition shadow"
              >
                <Check className="w-4 h-4" />
                <span>Kết nối Firebase Cloud</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
