import { TaskDocument } from '../types';

export const INITIAL_ASSIGNEES: string[] = [];

export const MOCK_TASKS: TaskDocument[] = [];
