# Hệ Thống Quản Lý CV - VNPT Kỹ Thuật

Ứng dụng quản lý, phân công và đôn đốc văn bản giao việc chuyên nghiệp cho chuyên viên kỹ thuật VNPT.

## Tính năng nổi bật:
- Quản lý văn bản, hạn báo cáo, đôn đốc tiến độ.
- Hệ thống thông báo đẩy (Browser Push Notification) khi văn bản còn ≤ 1 ngày.
- Xuất báo cáo Excel (.xlsx), sao lưu dữ liệu (.json).
- Tích hợp sẵn GitHub Actions tự động build và deploy lên GitHub Pages miễn phí.

## Cách deploy lên GitHub Pages:
1. Đẩy toàn bộ mã nguồn này lên repository GitHub của bạn:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<username>/<repo-name>.git
   git push -u origin main
   ```
2. Vào **Settings** > **Pages** trên GitHub repository > Chọn **Source: GitHub Actions**.
3. Website sẽ tự động được triển khai tại: `https://<username>.github.io/<repo-name>/`.

Xem chi tiết trong tệp: `HUONG_DAN_GITHUB.md` đính kèm.
